package com.java.ne.enums;


/*
 * Basic file note: this source file is part of the Utility Billing System backend.
 */
public enum TariffType {
    FLAT,
    TIER_BASED
}
